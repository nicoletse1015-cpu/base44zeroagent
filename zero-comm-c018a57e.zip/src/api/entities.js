import { base44 } from './base44Client';


export const Property = base44.entities.Property;

export const Favorite = base44.entities.Favorite;

export const ChatRoom = base44.entities.ChatRoom;

export const Message = base44.entities.Message;

export const Review = base44.entities.Review;

export const Report = base44.entities.Report;

export const Contract = base44.entities.Contract;

export const ViewingAppointment = base44.entities.ViewingAppointment;

export const PropertyView = base44.entities.PropertyView;

export const BlockedUser = base44.entities.BlockedUser;



// auth sdk:
export const User = base44.auth;